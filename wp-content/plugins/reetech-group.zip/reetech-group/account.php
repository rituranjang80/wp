<?php
/*
Plugin Name: My Static Files Plugin
Description: A plugin to include multiple static HTML, CSS, JavaScript, and image files.
Version: 1.0
Author: Your Name
*/

// Enqueue CSS and JS files
function my_static_files_enqueue() {
    // Enqueue CSS Files
    wp_enqueue_style('my-static-css-main', plugins_url('css/module.css', __FILE__));

    // Enqueue JavaScript Files
    wp_enqueue_script('my-static-js-main', plugins_url('javascript/javascript.js', __FILE__), array('jquery'), null, true);

    // Localize script to pass data from PHP to JavaScript (optional)
    wp_localize_script('my-static-js-main', 'myStaticData', array(
        'pluginUrl' => plugins_url('', __FILE__), // Pass plugin URL to JS
    ));
}
add_action('wp_enqueue_scripts', 'my_static_files_enqueue');

// Shortcode to include HTML content
function my_static_html_shortcode($atts) {
    // Extract shortcode attributes
    $atts = shortcode_atts(array(
        'file' => 'default.html', // Default HTML file
    ), $atts);

    // Get the HTML file path
    $file_path = plugin_dir_path(__FILE__) . 'templates/' . $atts['file'];

    // Check if the file exists
    if (file_exists($file_path)) {
        // Output the HTML file content directly (no <code> tags)
        ob_start();
        include $file_path;
        return ob_get_clean(); // Return the HTML content as-is
    } else {
        return '<p>Error: HTML file not found.</p>';
    }
}
add_shortcode('my_static_html', 'my_static_html_shortcode');